// ds3231.c - DS3231 RTC 和温度传感器驱动实现
#include <reg52.h>
#include "ds3231.h" // 包含驱动头文件
#include "config.h" // 包含配置头文件（通常包含 SDA, SCL 的 sbit 定义）

// --- DS3231 I2C 地址 ---
// DS3231 设备地址 (7位地址 1101000b，最低位为 R/W 位，写地址为 0xD0，读地址为 0xD1)
#define DS3231_ADDR 0xD0

// --- DS3231 寄存器地址定义 ---
// DS3231 采用 BCD 格式存储时间数据

#define DS3231_SEC_REG      0x00    // 秒寄存器 (00-59)，第7位是 CH (Clock Halt) 位
#define DS3231_MIN_REG      0x01    // 分寄存器 (00-59)
#define DS3231_HOUR_REG     0x02    // 时寄存器 (00-23 或 01-12)
#define DS3231_WEEK_REG     0x03    // 星期寄存器 (01-07)
#define DS3231_DAY_REG      0x04    // 日寄存器 (01-31)
#define DS3231_MON_REG      0x05    // 月寄存器 (01-12)，第7位是世纪位
#define DS3231_YEAR_REG     0x06    // 年寄存器 (00-99)
#define DS3231_A1SEC_REG    0x07    // 闹钟 1 秒
#define DS3231_A1MIN_REG    0x08    // 闹钟 1 分
#define DS3231_A1HOUR_REG   0x09    // 闹钟 1 时
#define DS3231_A1DAY_REG    0x0A    // 闹钟 1 日/星期
#define DS3231_A2MIN_REG    0x0B    // 闹钟 2 分
#define DS3231_A2HOUR_REG   0x0C    // 闹钟 2 时
#define DS3231_A2DAY_REG    0x0D    // 闹钟 2 日/星期
#define DS3231_CTRL_REG     0x0E    // 控制寄存器 (用于启用闹钟、方波输出等)
#define DS3231_STAT_REG     0x0F    // 状态寄存器 (包含 OSF 振荡器停止标志等)
#define DS3231_AGING_REG    0x10    // 老化调整寄存器
#define DS3231_TEMP_MSB     0x11    // 温度寄存器 (MSB)
#define DS3231_TEMP_LSB     0x12    // 温度寄存器 (LSB)

// --- BCD 码与十进制转换宏 ---
// DS3231 内部时间数据是 BCD (Binary Coded Decimal) 格式
#define BCD_TO_DEC(x) (((x)>>4)*10 + ((x)&0x0F)) // BCD 转换为十进制
                                                // 高4位 (x>>4) 是十位, 低4位 (x&0x0F) 是个位
#define DEC_TO_BCD(x) ((((x)/10)<<4) + ((x)%10)) // 十进制转换为 BCD

// --- I2C 软件模拟时序函数 ---

// I2C 延时函数
void DS3231_Delay_us(unsigned int us) {
    unsigned int i;
    while(us--) {
        for(i = 0; i < 10; i++);  // 空循环延时，用于调整 I2C 时序速度
    }
}

// I2C 起始信号 (Start Condition)
// SCL 为高电平时，SDA 由高变低
void DS3231_Start(void) {
    SDA = 1;
    SCL = 1;
    DS3231_Delay_us(5);
    
    SDA = 0; // SDA 下降沿
    DS3231_Delay_us(5);
    SCL = 0; // 钳住 SCL，准备发送数据
    DS3231_Delay_us(5);
}

// I2C 停止信号 (Stop Condition)
// SCL 为高电平时，SDA 由低变高
void DS3231_Stop(void) {
    SDA = 0;
    SCL = 1;
    DS3231_Delay_us(5);
    SDA = 1; // SDA 上升沿
    DS3231_Delay_us(5);
}

// 主机发送应答信号 (ACK)
// 主机在应答时隙拉低 SDA
void DS3231_Ack(void) {
    SDA = 0; // 发送 ACK (低电平)
    SCL = 1;
    DS3231_Delay_us(5);
    SCL = 0;
    DS3231_Delay_us(5);
}

// 主机发送非应答信号 (NACK)
// 主机在应答时隙拉高 SDA (通常在读取最后一个字节时使用)
void DS3231_NAck(void) {
    SDA = 1; // 发送 NACK (高电平)
    SCL = 1;
    DS3231_Delay_us(5);
    SCL = 0;
    DS3231_Delay_us(5);
}

// I2C 写入一个字节
// 返回值：bit (0=收到应答ACK, 1=未收到应答NACK)
bit DS3231_WriteByte(unsigned char dat) {
    unsigned char i;
    bit ack;
    
    
    
    // 发送 8 位数据
    for(i = 0; i < 8; i++) {
        if(dat & 0x80) {
            SDA = 1;
        } else {
            SDA = 0;
        }
        dat <<= 1; // 准备下一位
        
        SCL = 1;   // 拉高 SCL，从机读取数据
        DS3231_Delay_us(5);
        SCL = 0;   // 拉低 SCL，准备下一位数据
        DS3231_Delay_us(5);
    }
    
    // 读取从机应答 (第九个时钟周期)
    SDA = 1; // 主机释放 SDA (输入模式)
    SCL = 1; 
    DS3231_Delay_us(5);
    ack = SDA; // 读取 SDA 状态 (低电平表示 ACK)
    SCL = 0; 
    DS3231_Delay_us(5);
    
    return ack; // 返回应答状态
}

// I2C 读取一个字节
unsigned char DS3231_ReadByte(void) {
    unsigned char i, dat = 0;
    
    SDA = 1; // 主机释放 SDA (确保 SDA 处于输入模式)
    
    for(i = 0; i < 8; i++) {
        dat <<= 1; // 数据左移，腾出最低位
        
        SCL = 1;   // 拉高 SCL，从机输出数据
        DS3231_Delay_us(5);
        
        if(SDA) {  // 读取数据
            dat |= 0x01;
        }
        SCL = 0;   // 拉低 SCL，准备下一位
        DS3231_Delay_us(5);
    }
    
    return dat; // 返回读取到的字节
}

// --- DS3231 驱动核心函数 ---

// 写入 DS3231 寄存器 (单字节写入)
// 流程: Start -> DevAddr(W) -> RegAddr -> Data -> Stop
bit DS3231_WriteReg(unsigned char reg_addr, unsigned char dat) {
    DS3231_Start(); // 1. 发送起始信号
    
    // 2. 发送器件地址 (写方向)
    if(DS3231_WriteByte(DS3231_ADDR)) { 
        DS3231_Stop();
        return 1; // NACK 错误
    }
    
    // 3. 发送寄存器地址
    if(DS3231_WriteByte(reg_addr)) {
        DS3231_Stop();
        return 1; // NACK 错误
    }
    
    // 4. 发送数据
    if(DS3231_WriteByte(dat)) {
        DS3231_Stop();
        return 1; // NACK 错误
    }
    
    DS3231_Stop(); // 5. 发送停止信号
    return 0;      // 成功
}

// 读取 DS3231 寄存器 (随机读取)
// 流程: Start -> DevAddr(W) -> RegAddr -> Restart -> DevAddr(R) -> Read -> NACK -> Stop
unsigned char DS3231_ReadReg(unsigned char reg_addr) {
    unsigned char dat;
    
    // 1. 伪写入：设置内部寄存器地址指针
    DS3231_Start();
    DS3231_WriteByte(DS3231_ADDR);
    DS3231_WriteByte(reg_addr); // 发送要读取的寄存器地址
    
    // 2. 重启总线，进入读取模式
    DS3231_Start();
    DS3231_WriteByte(DS3231_ADDR | 0x01); // 发送器件地址 (读方向)
    
    // 3. 读取数据
    dat = DS3231_ReadByte();
    DS3231_NAck(); // 4. 发送 NACK (读取结束)
    DS3231_Stop(); // 5. 发送停止信号
    
    return dat;
}

// 初始化 DS3231
void DS3231_Init(void) {
    unsigned char status, seconds;
    
    // 读取状态寄存器
    status = DS3231_ReadReg(DS3231_STAT_REG);
    
    // 清除振荡器停止标志 (OSF - bit 7)，确保 RTC 正常工作
    if(status & 0x80) {
        DS3231_WriteReg(DS3231_STAT_REG, status & 0x7F);
    }
    
    // 检查秒寄存器的 CH 位 (Clock Halt - bit 7)
    seconds = DS3231_ReadReg(DS3231_SEC_REG);
    if(seconds & 0x80) {
        // 如果 CH 被设置 (时钟停止)，则清除 CH 位以启动振荡器
        DS3231_WriteReg(DS3231_SEC_REG, seconds & 0x7F);
    }
    
    // 禁用闹钟和方波输出，设置为默认控制状态
    DS3231_WriteReg(DS3231_CTRL_REG, 0x00);
}

// 检查 DS3231 是否正常工作
// 返回 1 (真) 如果 OSF (振荡器停止标志) 未设置
bit DS3231_IsWorking(void) {
    unsigned char status = DS3231_ReadReg(DS3231_STAT_REG);
    return !(status & 0x80); // 检查 OSF 位 (bit 7)
}

// 设置 DS3231 时间
void DS3231_SetTime(TIME_STRUCT *time) {
    // 写入秒，并清除 CH 位 (seconds & 0x7F)
    DS3231_WriteReg(DS3231_SEC_REG, DEC_TO_BCD(time->sec) & 0x7F); 
    DS3231_WriteReg(DS3231_MIN_REG, DEC_TO_BCD(time->min));
    // 写入小时 (DS3231 默认 24 小时模式，不需要处理 12/24 转换位)
    DS3231_WriteReg(DS3231_HOUR_REG, DEC_TO_BCD(time->hour));
    DS3231_WriteReg(DS3231_WEEK_REG, DEC_TO_BCD(time->week));
    DS3231_WriteReg(DS3231_DAY_REG, DEC_TO_BCD(time->day));
    // 写入月份 (月寄存器的高位包含世纪位，这里只写月份 BCD 部分)
    DS3231_WriteReg(DS3231_MON_REG, DEC_TO_BCD(time->month));
    DS3231_WriteReg(DS3231_YEAR_REG, DEC_TO_BCD(time->year));
}

// 获取 DS3231 时间
void DS3231_GetTime(TIME_STRUCT *time) {
    // 读取秒，并清除高位 (CH 位)
    time->sec = BCD_TO_DEC(DS3231_ReadReg(DS3231_SEC_REG) & 0x7F);
    // 读取分，并清除高位 (可能是 12/24 模式位)
    time->min = BCD_TO_DEC(DS3231_ReadReg(DS3231_MIN_REG) & 0x7F);
    // 读取时，清除高位 (可能是 12/24 模式位、AM/PM 位)
    time->hour = BCD_TO_DEC(DS3231_ReadReg(DS3231_HOUR_REG) & 0x3F);
    // 读取星期，清除高位
    time->week = BCD_TO_DEC(DS3231_ReadReg(DS3231_WEEK_REG) & 0x07);
    // 读取日，清除高位
    time->day = BCD_TO_DEC(DS3231_ReadReg(DS3231_DAY_REG) & 0x3F);
    // 读取月，清除世纪位
    time->month = BCD_TO_DEC(DS3231_ReadReg(DS3231_MON_REG) & 0x1F);
    // 读取年
    time->year = BCD_TO_DEC(DS3231_ReadReg(DS3231_YEAR_REG));
}

// 读取 DS3231 温度
// 返回值：温度值乘以 100 (避免使用浮点数，例如 25.75°C 返回 2575)
int DS3231_ReadTemperature(void) {
    unsigned char msb, lsb;
    int temperature;
    signed char temp_msb;
    
    // 读取温度寄存器 MSB 和 LSB
    msb = DS3231_ReadReg(DS3231_TEMP_MSB); // 整数部分
    lsb = DS3231_ReadReg(DS3231_TEMP_LSB); // 小数部分 (只有两位)
    
    // 将 MSB 转换为带符号数，处理负温度
    temp_msb = msb;
    
    // 温度计算公式：Temperature = MSB + LSB * 0.25
    // LSB 只有第 7、6 位有效，分别代表 0.5°C 和 0.25°C
    
    // 转换到 (int) * 100 的形式
    // MSB * 100 + (LSB/64) * 25 (因为 (LSB >> 6) 只能是 0, 1, 2, 3，代表 0, 0.25, 0.5, 0.75)
    
    // 无论正负温度，公式都是一样的 (DS3231 采用补码表示)
    temperature = temp_msb * 100 + ((lsb >> 6) * 25);
    
    return temperature;
}