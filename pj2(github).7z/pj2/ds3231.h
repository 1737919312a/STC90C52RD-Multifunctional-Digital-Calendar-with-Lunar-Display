// ds3231.h - DS3231 实时时钟(RTC)和温度传感器头文件
#ifndef _DS3231_H_    // 防止头文件重复包含的保护宏（开始）
#define _DS3231_H_    // 定义宏 _DS3231_H_

// --- I2C 接口引脚定义 ---
// 使用 sbit 定义模拟 I2C 通信的物理引脚
// 注意：为了避免编译错误，建议确保 P1 在包含 reg52.h 后被识别，或者调整 include 顺序
sbit SDA = P1^0;      // 定义 I2C 数据线 (Serial Data) 连接到单片机 P1.0 引脚 

sbit SCL = P1^1;      // 定义 I2C 时钟线 (Serial Clock) 连接到单片机 P1.1 引脚

// --- DS3231 设备地址 ---
// I2C 写地址 (读地址通常是写地址 + 1)
#define DS3231_ADDR 0xD0 

#include <reg52.h>    // 包含 8051 寄存器定义（为了识别 P1 等符号）

// --- 时间数据结构体定义 ---
// 使用结构体将时间相关的变量打包，方便在函数间整体传递
typedef struct {
    unsigned char sec;    // 秒 (0-59)
    unsigned char min;    // 分 (0-59)
    unsigned char hour;   // 时 (0-23, 24小时制)
    unsigned char week;   // 星期 (1-7)
    unsigned char day;    // 日 (1-31)
    unsigned char month;  // 月 (1-12)
    unsigned char year;   // 年 (只存储后两位，如 25 代表 2025)
} TIME_STRUCT;

// --- 函数原型声明 ---
// 声明这些函数以便在主程序或其他 .c 文件中调用

// 初始化 DS3231 (设置控制寄存器等)
void DS3231_Init(void);

// 检查 DS3231 是否在线/工作正常 (通常通过 I2C ACK 信号检测)
bit DS3231_IsWorking(void);

// 设置时间：将 TIME_STRUCT 结构体中的数据写入 DS3231 
void DS3231_SetTime(TIME_STRUCT *time);

// 读取时间：从 DS3231 读取当前时间并存入 TIME_STRUCT 结构体
void DS3231_GetTime(TIME_STRUCT *time);

// 读取 DS3231 内部集成的温度传感器数值
int DS3231_ReadTemperature(void);

// 底层函数：读取指定寄存器地址的一个字节数据
unsigned char DS3231_ReadReg(unsigned char reg_addr);

// 底层函数：向指定寄存器地址写入一个字节数据 (返回 bit 表示成功与否)
bit DS3231_WriteReg(unsigned char reg_addr, unsigned char dat);

#endif // 防止头文件重复包含的保护宏（结束）