#include <reg51.h>
#include <string.h>
#include <stdio.h>

// Type definitions
typedef unsigned char uchar;
typedef unsigned int  uint;

// Global time structure
typedef struct {
    uchar year;   // 0-99 ? 2000-2099
    uchar month;  // 1-12
    uchar day;    // 1-31
    uchar hour;   // 0-23
    uchar min;    // 0-59
    uchar sec;    // 0-59
    uchar week;   // 1-7
} TimeStruct;

// === Global Variables ===
TimeStruct currentTime = {25, 11, 14, 13, 45, 0, 5};  // 2025-11-14 13:45:00
uchar tempHumi[2] = {60, 25};  // [0]=RH%, [1]=Temp�C
uchar editMode = 0;
uint cnt = 0;
#define UPDATE_INTERVAL 100

// LCD pins (4-bit mode)
sbit LCD_RS = P3^5;
sbit LCD_RW = P3^6;
sbit LCD_EN = P3^7;
#define LCD_DATA P2

// === ROM Tables (code memory) ===
code uchar lunarPrefix[] = {0xC5, 0xFA, 0xC0, 0xFA, 0x3A, 0};

// Lunar month names (GB2312, 2 bytes each)
const code uchar lunarMonths[][2] = {
    {0xD5, 0xFD}, // ?
    {0xB6, 0xFE}, // ?
    {0xC8, 0xFD}, // ?
    {0xCB, 0xC4}, // ?
    {0xCE, 0xE5}, // ?
    {0xC1, 0xF9}, // ?
    {0xC6, 0xDF}, // ?
    {0xB0, 0xCB}, // ?
    {0xBE, 0xC5}, // ?
    {0xCA, 0xAE}, // ?
    {0xB6, 0xAC}, // ?
    {0xC0, 0xBC}  // ?
};

// Lunar day names (simplified, up to 30)
const code uchar * code lunarDays[] = {
    "??","??","??","??","??","??","??","??","??","??",
    "??","??","??","??","??","??","??","??","??","??",
    "??","??","??","??","??","??","??","??","??","??"
};

// === Function Prototypes ===
void LCD_Init(void);
void LCD_SendCommand(uchar cmd);
void LCD_SendData(uchar dat);
void LCD_ShowString(uchar x, uchar y, uchar *str);
void Delay_ms(uint ms);
void NumToStr(uchar val, uchar *buf, uchar width);
uchar GetMaxDay(uchar year, uchar month);
void GetLunarCalendar(uint year, uchar month, uchar day, uchar *out);
void UpdateDisplay(void);
void IncrementTime(void);
void WDT_Feed(void);  // Now safe

// === NumToStr using sprintf (small) ===
void NumToStr(uchar val, uchar *buf, uchar width) {
    sprintf((char*)buf, "%0*u", width, val);
}

// === Leap Year Aware Max Days ===
uchar GetMaxDay(uchar year, uchar month) {
    uchar days[13] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
    if (month == 2) {
        uint y = 2000 + year;
        if ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0))
            return 29;
    }
    return days[month];
}

// === GetLunarCalendar (ROM-safe) ===
void GetLunarCalendar(uint year, uchar month, uchar day, uchar *out) {
    uchar i = 0, j;
    uchar lm, ld;

    // Simplified mapping (for demo)
    lm = (month == 1) ? 11 : month - 2;  // Rough lunar shift
    ld = day - 1;

    // "??:"
    for (j = 0; lunarPrefix[j]; j++) out[i++] = lunarPrefix[j];

    // Month name
    out[i++] = lunarMonths[lm][0];
    out[i++] = lunarMonths[lm][1];

    // Day string (ASCII ? copy)
    {
        const uchar *d = lunarDays[ld];
        char c;
        while ((c = *d++) && i < 14) {
            out[i++] = c;
        }
    }
    out[i] = '\0';
}

// === LCD Driver (4-bit) ===
void LCD_Init(void) {
    Delay_ms(15);
    LCD_SendCommand(0x30); Delay_ms(5);
    LCD_SendCommand(0x30); Delay_ms(1);
    LCD_SendCommand(0x30);
    LCD_SendCommand(0x28); // 4-bit, 2 line
    LCD_SendCommand(0x0C); // Display on
    LCD_SendCommand(0x06); // Increment
    LCD_SendCommand(0x01); // Clear
    Delay_ms(2);
}

void LCD_SendCommand(uchar cmd) {
    LCD_RS = 0; LCD_RW = 0;
    LCD_DATA = cmd & 0xF0;
    LCD_EN = 1; Delay_ms(1); LCD_EN = 0;
    LCD_DATA = (cmd << 4) & 0xF0;
    LCD_EN = 1; Delay_ms(1); LCD_EN = 0;
}

void LCD_SendData(uchar dat) {
    LCD_RS = 1; LCD_RW = 0;
    LCD_DATA = dat & 0xF0;
    LCD_EN = 1; Delay_ms(1); LCD_EN = 0;
    LCD_DATA = (dat << 4) & 0xF0;
    LCD_EN = 1; Delay_ms(1); LCD_EN = 0;
}

void LCD_ShowString(uchar x, uchar y, uchar *str) {
    uchar addr = 0x80 + (y * 0x40) + x;
    LCD_SendCommand(addr);
    while (*str) LCD_SendData(*str++);
}

// === Delay (12MHz) ===
void Delay_ms(uint ms) {
    uint i, j;
    for (i = 0; i < ms; i++)
        for (j = 0; j < 120; j++);
}

// === Watchdog Feed (Standard 8051 - disable or use timer) ===
// For Keil + generic 8051: use PCA or disable WDT
void WDT_Feed(void) {
    // If using STC89 with WDT enabled in config:
    // #pragma asm
    //   MOV WDT_CONTR, #0x10
    // #pragma endasm
    // Otherwise: leave empty or use PCA watchdog
}

// === UpdateDisplay ===
void UpdateDisplay(void) {
    uchar str[17];
    uchar lunar[16];
    uchar i, j;

    memset(str, 0, sizeof(str));
    memset(lunar, 0, sizeof(lunar));

    // Line 1: 20YY-MM-DD
    str[0] = '2'; str[1] = '0';
    NumToStr(currentTime.year, str+2, 2);
    str[4] = '-'; NumToStr(currentTime.month, str+5, 2);
    str[7] = '-'; NumToStr(currentTime.day, str+8, 2);
    str[10] = '\0';
    LCD_ShowString(0, 0, str);

    // Line 2: HH:MM:SS
    NumToStr(currentTime.hour, str, 2);
    str[2] = ':'; NumToStr(currentTime.min, str+3, 2);
    str[5] = ':'; NumToStr(currentTime.sec, str+6, 2);
    str[8] = '\0';
    LCD_ShowString(0, 1, str);

    // Line 3: ??
    GetLunarCalendar(2000 + currentTime.year, currentTime.month, currentTime.day, lunar);
    LCD_ShowString(0, 2, lunar);

    // Line 4: T:XXC H:YY%
    str[0] = 'T'; str[1] = ':';
    NumToStr(tempHumi[1], str+2, 2);
    str[4] = 'C'; str[5] = ' ';
    str[6] = 'H'; str[7] = ':';
    NumToStr(tempHumi[0], str+8, 2);
    str[10] = '%'; str[11] = '\0';
    LCD_ShowString(0, 3, str);

    LCD_ShowString(14, 3, editMode ? "ED" : "  ");
}

// === IncrementTime ===
void IncrementTime(void) {
    uchar maxDay;

    if (++currentTime.sec >= 60) {
        currentTime.sec = 0;
        if (++currentTime.min >= 60) {
            currentTime.min = 0;
            if (++currentTime.hour >= 24) {
                currentTime.hour = 0;
                if (++currentTime.day > (maxDay = GetMaxDay(currentTime.year, currentTime.month))) {
                    currentTime.day = 1;
                    if (++currentTime.month > 12) {
                        currentTime.month = 1;
                        if (++currentTime.year > 99) currentTime.year = 0;
                    }
                }
                if (++currentTime.week > 7) currentTime.week = 1;
            }
        }
    }
}

// === Main ===
void main(void) {
    LCD_Init();
    UpdateDisplay();

    while (1) {
        WDT_Feed();
        if (++cnt >= UPDATE_INTERVAL) {
            cnt = 0;
            IncrementTime();
            UpdateDisplay();
        }
        Delay_ms(10);
    }
}