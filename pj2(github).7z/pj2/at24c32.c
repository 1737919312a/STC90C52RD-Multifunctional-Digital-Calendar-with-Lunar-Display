// at24c32.c - AT24C02 EEPROM 驱动实现文件
// 注意：该文件实现了 I2C 软件模拟时序，用于控制 AT24C02
#include "at24c32.h"
#include "config.h"

// I2C 延时函数
// 用于产生 I2C 通信所需的时序间隔
void AT24C02_Delay_us(unsigned int us) {
    unsigned int i;
    while(us--) {
        for(i = 0; i < 10; i++);  // 空循环延时，需根据系统晶振频率调整
    }
}

// ... 其余代码保持不变 ...

// I2C 起始信号 (Start Condition)
// 协议规定：当 SCL 为高电平时，SDA 由高变低为起始信号
void AT24C02_Start(void) {
    AT24C02_SDA = 1;    // 确保 SDA 为高
    AT24C02_SCL = 1;    // 确保 SCL 为高
    AT24C02_Delay_us(5);
    
    AT24C02_SDA = 0;    // 拉低 SDA，产生下降沿 (START)
    AT24C02_Delay_us(5);
    AT24C02_SCL = 0;    // 拉低 SCL，钳住总线，准备发送数据
    AT24C02_Delay_us(5);
}

// I2C 停止信号 (Stop Condition)
// 协议规定：当 SCL 为高电平时，SDA 由低变高为停止信号
void AT24C02_Stop(void) {
    AT24C02_SDA = 0;    // 确保 SDA 为低
    AT24C02_SCL = 1;    // 拉高 SCL
    AT24C02_Delay_us(5);
    AT24C02_SDA = 1;    // 拉高 SDA，产生上升沿 (STOP)
    AT24C02_Delay_us(5);
}

// 等待从机应答 (Wait for Acknowledge)
// 返回值：0=接收到应答(ACK), 1=未接收到应答(NACK)
bit AT24C02_WaitAck(void) {
    bit ack;
    
    AT24C02_SDA = 1;    // 主机释放 SDA 数据线 (输入模式)
    AT24C02_SCL = 1;    // 拉高 SCL，让从机放数据
    AT24C02_Delay_us(5);
    
    ack = AT24C02_SDA;  // 读取 SDA 线状态 (低电平为有效应答)
    
    AT24C02_SCL = 0;    // 拉低 SCL，结束应答位
    AT24C02_Delay_us(5);
    
    return ack;
}

// I2C 写一个字节数据 (发送数据)
// 从高位到低位依次发送 8 位数据
void AT24C02_WriteByteData(unsigned char dat) {
    unsigned char i;
    
    for(i = 0; i < 8; i++) {
        // 判断最高位是 1 还是 0
        if(dat & 0x80) {
            AT24C02_SDA = 1;
        } else {
            AT24C02_SDA = 0;
        }
        dat <<= 1;      // 数据左移，准备下一位
        
        AT24C02_SCL = 1; // 拉高 SCL，通知从机读取数据
        AT24C02_Delay_us(5);
        AT24C02_SCL = 0; // 拉低 SCL，准备改变数据
        AT24C02_Delay_us(5);
    }
}

// I2C 读一个字节数据
// 从高位到低位依次读取 8 位数据
unsigned char AT24C02_ReadByteData(void) {
    unsigned char i, dat = 0;
    
    AT24C02_SDA = 1;    // 主机释放 SDA 线 (输入模式)
    for(i = 0; i < 8; i++) {
        dat <<= 1;      // 数据左移，腾出最低位
        AT24C02_SCL = 1; // 拉高 SCL，读取数据
        AT24C02_Delay_us(5);
        
        if(AT24C02_SDA) { // 如果读到高电平
            dat |= 0x01;  // 最低位置 1
        }
        
        AT24C02_SCL = 0; // 拉低 SCL
        AT24C02_Delay_us(5);
    }
    
    return dat;
}

// 发送应答信号 (ACK)
// 主机拉低 SDA，表示已收到数据且继续接收
void AT24C02_Ack(void) {
    AT24C02_SDA = 0;
    AT24C02_SCL = 1;
    AT24C02_Delay_us(5);
    AT24C02_SCL = 0;
    AT24C02_Delay_us(5);
}

// 发送非应答信号 (NACK)
// 主机拉高 SDA，表示数据接收结束
void AT24C02_NAck(void) {
    AT24C02_SDA = 1;
    AT24C02_SCL = 1;
    AT24C02_Delay_us(5);
    AT24C02_SCL = 0;
    AT24C02_Delay_us(5);
}

// 初始化 AT24C02 接口
// 将总线置于空闲状态 (高电平)
void AT24C02_Init(void) {
    AT24C02_SDA = 1;
    AT24C02_SCL = 1;
}

// 向 AT24C02 指定地址写入一个字节
// 流程: Start -> DevAddr(W) -> WordAddr -> Data -> Stop
void AT24C02_WriteByte(unsigned int word_addr, unsigned char dat) {
    // AT24C02 只有 256 字节 (0x00-0xFF)，检查地址越界
    if(word_addr > 0xFF) return;
    
    
    
    AT24C02_Start(); // 发送起始信号
    
    // 发送器件地址 + 写方向 (0xA0)
    AT24C02_WriteByteData(AT24C02_ADDR); 
    if(AT24C02_WaitAck()) { // 等待应答，无应答则停止
        AT24C02_Stop();
        return;
    }
    
    // 发送存储单元地址 (AT24C02 使用 8 位地址)
    AT24C02_WriteByteData(word_addr & 0xFF); 
    if(AT24C02_WaitAck()) {
        AT24C02_Stop();
        return;
    }
    
    // 发送要写入的数据
    AT24C02_WriteByteData(dat);
    if(AT24C02_WaitAck()) {
        AT24C02_Stop();
        return;
    }
    
    AT24C02_Stop(); // 发送停止信号
    
    // 等待 EEPROM 内部写入周期完成 - 增加等待时间
    // EEPROM 写入通常需要 5-10ms
    AT24C02_Delay_us(10000); // 增加到10ms确保写入完成
}

// 从 AT24C02 指定地址读取一个字节 (随机读取)
// 流程: Start -> DevAddr(W) -> WordAddr -> Start -> DevAddr(R) -> Read -> NACK -> Stop
unsigned char AT24C02_ReadByte(unsigned int word_addr) {
    unsigned char dat;
    
    // AT24C02 只有 256 字节 (0x00-0xFF)
    if(word_addr > 0xFF) return 0xFF;
    
    
    
    // 第一步：伪写入，用于设置内部地址指针
    AT24C02_Start();
    AT24C02_WriteByteData(AT24C02_ADDR); // 发送写命令
    if(AT24C02_WaitAck()) {
        AT24C02_Stop();
        return 0xFF;
    }
    
    AT24C02_WriteByteData(word_addr & 0xFF); // 设置要读取的地址
    if(AT24C02_WaitAck()) {
        AT24C02_Stop();
        return 0xFF;
    }
    
    // 第二步：重启总线，发送读命令
    AT24C02_Start();
    AT24C02_WriteByteData(AT24C02_ADDR | 0x01); // 发送读命令 (0xA1)
    if(AT24C02_WaitAck()) {
        AT24C02_Stop();
        return 0xFF;
    }
    
    // 读取数据
    dat = AT24C02_ReadByteData();
    AT24C02_NAck(); // 读取最后一个字节后发送 NACK
    AT24C02_Stop(); // 停止信号
    
    return dat;
}

// 向 AT24C02 连续写入多个字节
// 注意：该函数实现的是循环字节写入 (Byte Write)，效率较低但简单安全
// (若使用页写入 Page Write，需要注意不能跨越页边界)
bit AT24C02_WriteBytes(unsigned int word_addr, unsigned char *buf, unsigned char len) {
    unsigned char i;
    
    // 检查地址范围是否溢出
    if(word_addr + len > 0x100) return 1; // 错误 - 超出范围
    
    for(i = 0; i < len; i++) {
        // 逐字节调用写入函数
        AT24C02_WriteByte(word_addr + i, buf[i]);
    }
    
    return 0; // 成功
}

// 从 AT24C02 连续读取多个字节 (顺序读取)
// 流程: Start -> DevAddr(W) -> WordAddr -> Start -> DevAddr(R) -> Read+ACK ... -> Read+NACK -> Stop
bit AT24C02_ReadBytes(unsigned int word_addr, unsigned char *buf, unsigned char len) {
    unsigned char i;
    
    // 检查地址范围是否溢出
    if(word_addr + len > 0x100) return 1; // 错误 - 超出范围
    
    // 设置读取起始地址
    AT24C02_Start();
    AT24C02_WriteByteData(AT24C02_ADDR); // 写命令
    if(AT24C02_WaitAck()) {
        AT24C02_Stop();
        return 1; // 错误
    }
    
    AT24C02_WriteByteData(word_addr & 0xFF); // 发送起始地址
    if(AT24C02_WaitAck()) {
        AT24C02_Stop();
        return 1; // 错误
    }
    
    // 重启总线，进入读取模式
    AT24C02_Start();
    AT24C02_WriteByteData(AT24C02_ADDR | 0x01); // 读命令
    if(AT24C02_WaitAck()) {
        AT24C02_Stop();
        return 1; // 错误
    }
    
    // 循环读取数据
    for(i = 0; i < len; i++) {
        buf[i] = AT24C02_ReadByteData();
        if(i == len - 1) {
            AT24C02_NAck(); // 最后一个字节，发送 NACK 结束
        } else {
            AT24C02_Ack();  // 不是最后一个字节，发送 ACK 请求更多数据
        }
    }
    
    AT24C02_Stop();
    return 0; // 成功
}