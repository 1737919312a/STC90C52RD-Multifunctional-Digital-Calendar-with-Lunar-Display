// key4x4.h - 4x4矩阵键盘驱动头文件
#ifndef __KEY4X4_H__
#define __KEY4X4_H__

#include "config.h"

// --- 矩阵键盘引脚定义 ---
// 行线连接到P1.4-P1.7
sbit KEY_ROW0 = P1^4;
sbit KEY_ROW1 = P1^5;
sbit KEY_ROW2 = P1^6;
sbit KEY_ROW3 = P1^7;

// 列线连接到P1.0-P1.3
sbit KEY_COL0 = P1^0;
sbit KEY_COL1 = P1^1;
sbit KEY_COL2 = P1^2;
sbit KEY_COL3 = P1^3;

// --- 函数原型声明 ---

// 初始化4x4键盘
void Key4x4_Init(void);

// 扫描键盘，返回按键值 (0-15)，无按键返回0xFF
uchar Key4x4_Scan(void);

// 获取按键值并处理按键抖动，返回按键值 (0-15)，无按键返回0xFF
uchar Key4x4_GetKey(void);

// 等待按键释放
void Key4x4_WaitRelease(void);

#endif