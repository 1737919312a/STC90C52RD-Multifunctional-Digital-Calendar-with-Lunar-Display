// at24c32.h - AT24C02 EEPROM 驱动头文件
#ifndef __AT24C32_H__   // 防止头文件重复包含的保护宏（开始）
#define __AT24C32_H__   // 定义宏 __AT24C32_H__

#include "config.h"     // 包含系统配置文件（引入数据类型定义等）

// --- I2C 设备地址 ---
// AT24C02 的 I2C 写地址 (假设硬件上 A0-A2 引脚全部接地)
// 二进制: 1010 (固定) + 000 (地址位) + 0 (写位) = 0xA0
#define AT24C02_ADDR 0xA0

// --- I2C 引脚定义 ---
// 使用 sbit 定义模拟 I2C 通信的物理引脚
// 特别说明：这里特意更换了引脚，使用了 P1.2 和 P1.3
// 原始注释指出这是为了避免与 DS3231 (通常接在 P1.0/P1.1) 发生冲突，实现双总线隔离

sbit AT24C02_SDA = P1^2;  // EEPROM 数据线 (SDA) 映射到 P1.2
sbit AT24C02_SCL = P1^3;  // EEPROM 时钟线 (SCL) 映射到 P1.3

// --- 函数原型声明 ---
// 声明驱动函数供外部调用

// 初始化 I2C 总线接口
void AT24C02_Init(void);

// 向指定地址写入单字节数据
// 参数：word_addr=存储单元地址, dat=写入的数据
void AT24C02_WriteByte(unsigned int word_addr, unsigned char dat);

// 从指定地址读取单字节数据
// 参数：word_addr=存储单元地址; 返回值：读取到的数据
unsigned char AT24C02_ReadByte(unsigned int word_addr);

// 连续写入多个字节
// 参数：buf=数据源指针, len=长度; 返回值：bit(1成功/0失败)
bit AT24C02_WriteBytes(unsigned int word_addr, unsigned char *buf, unsigned char len);

// 连续读取多个字节
// 参数：buf=接收缓冲区指针, len=长度; 返回值：bit(1成功/0失败)
bit AT24C02_ReadBytes(unsigned int word_addr, unsigned char *buf, unsigned char len);

// 微秒级延时函数 (用于 I2C 时序控制)
void AT24C02_Delay_us(unsigned int us); // 原注释：添加函数原型声明

// --- 兼容性宏定义 ---
// 为了保持原有代码的兼容性 (主程序中可能调用的是 AT24C32_ 开头的函数)，
// 这里将 AT24C32 的函数名直接映射到上述 AT24C02 的实现函数上。
#define AT24C32_Init        AT24C02_Init
#define AT24C32_WriteByte   AT24C02_WriteByte
#define AT24C32_ReadByte    AT24C02_ReadByte
#define AT24C32_WriteBytes  AT24C02_WriteBytes
#define AT24C32_ReadBytes   AT24C02_ReadBytes

#endif // 防止头文件重复包含的保护宏（结束）