// key4x4.c - 4x4矩阵键盘驱动程序实现
#include "key4x4.h"
#include "lcd12864.h"
#include "ds3231.h"
#include "intrins.h"

// 按键映射表
// 0  1  2  3
// 4  5  6  7
// 8  9  10 11
// 12 13 14 15
code uchar KeyMap[16] = {
    0, 1, 2, 3,      // 第一行
    4, 5, 6, 7,      // 第二行
    8, 9, 10, 11,    // 第三行
    12, 13, 14, 15   // 第四行
};

// 按键字符映射表 (用于显示)
code uchar KeyCodeMap[16] = {
    '0', '1', '2', '3',
    '4', '5', '6', '7',
    '8', '9', 'A', 'B',
    'C', 'D', 'E', 'F'
};

// 延时函数
void Key_Delay(uchar ms) {
    uchar i, j;
    for (i = 0; i < ms; i++)
        for (j = 0; j < 115; j++);
}

// 初始化4x4键盘
void Key4x4_Init(void) {
    // 初始化行线为输出高电平
    KEY_ROW0 = 1;
    KEY_ROW1 = 1;
    KEY_ROW2 = 1;
    KEY_ROW3 = 1;
}

// 扫描按键,返回按键值 (0-15),无按键返回0xFF
uchar Key4x4_Scan(void) {
    uchar row, col;
    uchar temp = 0xFF;
    
    // 检查每一行
    KEY_ROW0 = 0; KEY_ROW1 = 1; KEY_ROW2 = 1; KEY_ROW3 = 1;
    Key_Delay(1);
    if (!(KEY_COL0 && KEY_COL1 && KEY_COL2 && KEY_COL3)) {
        row = 0;
        goto check_col;
    }
    
    KEY_ROW0 = 1; KEY_ROW1 = 0; KEY_ROW2 = 1; KEY_ROW3 = 1;
    Key_Delay(1);
    if (!(KEY_COL0 && KEY_COL1 && KEY_COL2 && KEY_COL3)) {
        row = 1;
        goto check_col;
    }
    
    KEY_ROW0 = 1; KEY_ROW1 = 1; KEY_ROW2 = 0; KEY_ROW3 = 1;
    Key_Delay(1);
    if (!(KEY_COL0 && KEY_COL1 && KEY_COL2 && KEY_COL3)) {
        row = 2;
        goto check_col;
    }
    
    KEY_ROW0 = 1; KEY_ROW1 = 1; KEY_ROW2 = 1; KEY_ROW3 = 0;
    Key_Delay(1);
    if (!(KEY_COL0 && KEY_COL1 && KEY_COL2 && KEY_COL3)) {
        row = 3;
        goto check_col;
    }
    
    return 0xFF; // 无按键按下
    
check_col:
    // 检查具体是哪一列
    for (col = 0; col < 4; col++) {
        if (col == 0) {
            if (!KEY_COL0) {
                temp = row * 4 + col;
                break;
            }
        } else if (col == 1) {
            if (!KEY_COL1) {
                temp = row * 4 + col;
                break;
            }
        } else if (col == 2) {
            if (!KEY_COL2) {
                temp = row * 4 + col;
                break;
            }
        } else if (col == 3) {
            if (!KEY_COL3) {
                temp = row * 4 + col;
                break;
            }
        }
    }
    
    return temp;
}

// 获取按键值(带消抖和等待释放),返回按键值 (0-15),无按键返回0xFF
uchar Key4x4_GetKey(void) {
    uchar key = 0xFF;
    
    key = Key4x4_Scan();
    if (key != 0xFF) {
        Key_Delay(10); // 消抖延时
        if (Key4x4_Scan() == key) {
            // 等待按键释放
            while (Key4x4_Scan() != 0xFF);
            return key;
        }
    }
    return 0xFF;
}

// 等待按键释放
void Key4x4_WaitRelease(void) {
    while (Key4x4_Scan() != 0xFF);
}