// lcd12864.c - LCD12864 液晶显示器驱动程序实现 (ST7920 控制器)
#include "lcd12864.h"
#include "intrins.h" // 包含 Keil C51 的内联函数，如 _nop_()

// ... existing code ...
// 延时函数
// 用于提供命令执行和数据处理所需的时间间隔
void LCD_Delay(uchar ms) {
    uchar i, j;
    // 这是一个软件延时函数，需要根据实际单片机时钟频率校准
    for (i = 0; i < ms; i++) // 外层循环控制毫秒数
        for (j = 0; j < 115; j++); // 内层循环控制实际延时时间
}
// ... existing code ...

// ST7920 写入命令 (并行模式)
void LCD_WriteCmd(uchar cmd) {
    LCD_RS = 0;     // RS = 0: 命令模式 (Register Select)
    LCD_RW = 0;     // RW = 0: 写入模式 (Read/Write)
    
    // 将命令数据放到数据总线上
    LCD_DATA = cmd;
    
    // 产生 EN 使能信号：高脉冲
    LCD_EN = 1;
    _nop_();        // 插入空操作，确保 EN 脉冲宽度
    LCD_EN = 0;
    
    LCD_Delay(5);   // 等待命令执行完成 (ST7920 部分命令需要较长执行时间)
}

// ST7920 写入数据 (并行模式)
void LCD_WriteData(uchar dat) {
    LCD_RS = 1;     // RS = 1: 数据模式
    LCD_RW = 0;     // RW = 0: 写入模式
    
    // 将数据放到数据总线上
    LCD_DATA = dat;
    
    // 产生 EN 使能信号：高脉冲
    LCD_EN = 1;
    _nop_();        // 确保 EN 脉冲宽度
    LCD_EN = 0;
    
    LCD_Delay(5);   // 等待数据被 LCD 处理
}

// LCD 初始化 (ST7920 控制器)
void LCD_Init(void) {
    // 设置为并行通信模式
    // ST7920 可通过 PSB 引脚选择串行或并行模式
    LCD_PSB = 1;
    
    // 硬件复位 LCD 模块
    LCD_RST = 0;
    LCD_Delay(50);
    LCD_RST = 1;
    LCD_Delay(50);
    
    // --- ST7920 初始化序列（通常用于设置功能、显示模式和清屏） ---
    
    // 1. 设置基本指令集
    LCD_WriteCmd(0x30);   // Function Set: 8位数据接口, 基本指令集 (Basic Instruction Set)
    LCD_Delay(5);
    LCD_WriteCmd(0x30);   // (重复设置，确保稳定)
    LCD_Delay(5);
    
    // 2. 显示开关控制
    LCD_WriteCmd(0x0C);   // Display ON/OFF: 显示开 (D=1), 光标关 (C=0), 光标不闪烁 (B=0)
    LCD_Delay(5);
    
    // 3. 清除屏幕并复位地址
    LCD_WriteCmd(0x01);   // Clear Display: 清除所有显示，地址指针归零 (所需时间较长)
    LCD_Delay(20);        // 必须等待清屏完成
    
    // 4. 设置输入模式
    LCD_WriteCmd(0x06);   // Entry Mode Set: 写入数据后地址自动增加 (I/D=1)，不移动显示 (SH=0)
    LCD_Delay(5);

    // --- 启用图形显示模式 (Graphic Mode) ---
    
    // 5. 切换到扩展指令集
    LCD_WriteCmd(0x34);   // Function Set: 扩展指令集 (Extended Instruction Set)
    LCD_Delay(5);
    
    // 6. 开启图形显示
    LCD_WriteCmd(0x36);   // Function Set: 扩展指令集 + 图形显示开 (G=1)
    LCD_Delay(5);
    
    // 7. 切换回基本指令集 (准备文本/图形混合操作)
    LCD_WriteCmd(0x30);   // Function Set: 基本指令集 (Basic Instruction Set)
    LCD_Delay(5);
    
    // 8. 再次确认显示开关状态 (确保显示已开启)
    LCD_WriteCmd(0x0C);   // Display ON/OFF: 显示开, 光标关
    LCD_Delay(5);
}

// 清除显示屏幕
void LCD_Clear(void) {
    LCD_WriteCmd(0x01); // 清屏指令
    LCD_Delay(20);      // 必须等待清屏完成
}

// 设置显示位置
// 用于设置 DDRAM 地址，确定下一个字符的写入位置
// 参数：x-列 (0-7), y-行 (0-3)
void LCD_SetPos(uchar x, uchar y) {
    uchar addr;
    // ST7920 的四行显示地址映射是跳跃的 (LCD1602兼容模式)
    switch(y) {
        case 0: addr = 0x80 + x; break; // 第一行 (地址 0x80 - 0x8F)
        case 1: addr = 0x90 + x; break; // 第二行 (地址 0x90 - 0x9F)
        case 2: addr = 0x88 + x; break; // 第三行 (地址 0x88 - 0x8F, 内存地址是交错的)
        case 3: addr = 0x98 + x; break; // 第四行 (地址 0x98 - 0x9F)
        default: addr = 0x80; break;    // 默认为第一行第一列
    }
    // Set DDRAM Address 指令的格式是 0b1xxxxxxx，其中 xxxxxxx 是地址
    LCD_WriteCmd(addr);
}

// 显示字符串
// 参数：x-起始列, y-起始行, str-待显示的字符串
void LCD_ShowString(uchar x, uchar y, uchar *str) {
    LCD_SetPos(x, y); // 设置起始位置
    while(*str) {
        LCD_WriteData(*str++); // 循环写入字符串中的每个字符
    }
}