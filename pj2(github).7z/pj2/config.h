// config.h - 系统配置文件
#ifndef __CONFIG_H__      // 防止头文件被重复包含的保护宏（开始）：如果未定义过此宏，则处理以下内容
#define __CONFIG_H__      // 定义宏 __CONFIG_H__，标记此文件已被包含，防止后续重复包含出错

#include <reg52.h>        // 包含标准 8051 单片机寄存器定义文件（定义了 P0-P3 等特殊功能寄存器）

// --- 类型定义区 ---
// 使用 typedef 给常用的数据类型起别名，为了代码编写更简便且增加可读性
typedef unsigned char uchar; // 将 unsigned char (8位无符号整数, 范围 0-255) 重命名为 uchar
typedef unsigned int uint;   // 将 unsigned int (16位无符号整数, 范围 0-65535) 重命名为 uint


// --- 硬件引脚配置区 ---
// 整点报时蜂鸣器引脚定义
// sbit 是 Keil C51 编译器的特殊关键字，用于定义可位寻址的特殊功能寄存器位
sbit HOURLY_BUZZER = P2^7;   // 定义变量 HOURLY_BUZZER 直接映射到单片机 P2 端口的第 7 号物理引脚


#endif                    // 防止头文件被重复包含的保护宏（结束）