// ds1302.h - DS1302 RTC driver
#ifndef __DS1302_H__
#define __DS1302_H__

#include "config.h"

// DS1302 pin definitions
sbit DS1302_CLK = P1^4;
sbit DS1302_DAT = P1^5;
sbit DS1302_RST = P1^6;

// Function declarations
uchar BCD2DEC(uchar bcd);
uchar DEC2BCD(uchar dec);
void DS1302_WriteByte(uchar dat);
uchar DS1302_ReadByte(void);
void DS1302_Write(uchar addr, uchar dat);
uchar DS1302_Read(uchar addr);
void DS1302_Init(void);
void DS1302_SetTime(TIME_STRUCT *time);
void DS1302_GetTime(TIME_STRUCT *time);
bit DS1302_IsWorking(void);
bit DS1302_TestComm(void);  // Test DS1302 communication

#endif