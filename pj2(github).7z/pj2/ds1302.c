// ds1302.c - DS1302 RTC driver
#include "ds1302.h"

// ???????
void Delay_ms(unsigned int ms);
// BCD to decimal conversion
uchar BCD2DEC(uchar bcd) {
    uchar result = (bcd >> 4) * 10 + (bcd & 0x0F);
    // Boundary check
    if (result > 99) result = 99;
    return result;
}

// Decimal to BCD conversion
uchar DEC2BCD(uchar dec) {
    // Boundary check
    if (dec > 99) dec = 99;
    return ((dec / 10) << 4) + (dec % 10);
}

// Write one byte to DS1302
void DS1302_WriteByte(uchar dat) {
    uchar i;
    for(i = 0; i < 8; i++) {
        DS1302_CLK = 0;
        DS1302_DAT = dat & 0x01;
        dat >>= 1;
        DS1302_CLK = 1;
    }
}

// Read one byte from DS1302
uchar DS1302_ReadByte(void) {
    uchar i, dat = 0;
    for(i = 0; i < 8; i++) {
        DS1302_CLK = 0;
        dat >>= 1;
        if(DS1302_DAT) dat |= 0x80;
        DS1302_CLK = 1;
    }
    return dat;
}

// Write data to DS1302 register
void DS1302_Write(uchar addr, uchar dat) {
    DS1302_RST = 0;
    DS1302_CLK = 0;
    DS1302_RST = 1;
    DS1302_WriteByte(addr);
    DS1302_WriteByte(dat);
    DS1302_RST = 0;
}

// Read data from DS1302 register
uchar DS1302_Read(uchar addr) {
    uchar dat;
    DS1302_RST = 0;
    DS1302_CLK = 0;
    DS1302_RST = 1;
    DS1302_WriteByte(addr | 0x01);
    dat = DS1302_ReadByte();
    DS1302_RST = 0;
    return dat;
}

// Initialize DS1302
void DS1302_Init(void) {
    // Initialize time (default value)
    DS1302_Write(0x8E, 0x00);  // Disable write protection
    // Set default time to January 1, 2025, 00:00:00
    DS1302_Write(0x80, 0x00);  // Second=0
    DS1302_Write(0x82, 0x00);  // Minute=0
    DS1302_Write(0x84, 0x00);  // Hour=0
    DS1302_Write(0x86, 0x01);  // Day=1
    DS1302_Write(0x88, 0x01);  // Month=1
    DS1302_Write(0x8A, 0x01);  // Week=1
    DS1302_Write(0x8C, 0x25);  // Year=25 (2025)
    DS1302_Write(0x8E, 0x80);  // Enable write protection
}

// Set DS1302 time
void DS1302_SetTime(TIME_STRUCT *time) {
    DS1302_Write(0x8E, 0x00);  // Disable write protection
    DS1302_Write(0x80, DEC2BCD(time->sec));
    DS1302_Write(0x82, DEC2BCD(time->min));
    DS1302_Write(0x84, DEC2BCD(time->hour));
    DS1302_Write(0x86, DEC2BCD(time->day));
    DS1302_Write(0x88, DEC2BCD(time->month));
    DS1302_Write(0x8A, DEC2BCD(time->week));
    DS1302_Write(0x8C, DEC2BCD(time->year));
    DS1302_Write(0x8E, 0x80);  // Enable write protection
}

// Get DS1302 time
void DS1302_GetTime(TIME_STRUCT *time) {
    uchar temp;
    
    temp = DS1302_Read(0x81);
    time->sec = BCD2DEC(temp);
    
    temp = DS1302_Read(0x83);
    time->min = BCD2DEC(temp);
    
    temp = DS1302_Read(0x85);
    time->hour = BCD2DEC(temp);
    
    temp = DS1302_Read(0x87);
    time->day = BCD2DEC(temp);
    
    temp = DS1302_Read(0x89);
    time->month = BCD2DEC(temp);
    
    temp = DS1302_Read(0x8B);
    time->week = BCD2DEC(temp);
    
    temp = DS1302_Read(0x8D);
    time->year = BCD2DEC(temp);
    
    // Validate time values to prevent abnormal data
    // If seconds exceed 59, reset to 0
    if(time->sec > 59) time->sec = 0;
    if(time->min > 59) time->min = 0;
    if(time->hour > 23) time->hour = 0;
    if(time->day < 1 || time->day > 31) time->day = 1;
    if(time->month < 1 || time->month > 12) time->month = 1;
    if(time->week < 1 || time->week > 7) time->week = 1;
    // For year values, 99 represents 2099, but normally should be 25 for 2025
    if(time->year > 99) time->year = 25;  // Default to 25 for 2025
}

// Check if DS1302 is working
bit DS1302_IsWorking(void) {
    uchar sec1, sec2;
    
    // Read seconds twice, if values are consistent, RTC is working
    sec1 = DS1302_Read(0x81);  // Read seconds
    Delay_ms(10);
    sec2 = DS1302_Read(0x81);  // Read seconds again
    
    // If two readings are inconsistent or exceed range, RTC is not working
    if(sec1 != sec2 || sec1 > 0x99) {
        return 0;  // RTC not working
    }
    return 1;  // RTC working
}

// Test DS1302 communication
bit DS1302_TestComm(void) {
    uchar test_val;
    
    // Try to read seconds register
    test_val = DS1302_Read(0x81);
    
    // If value is within valid range, communication is successful
    if(test_val <= 0x99) {
        return 1;  // Communication successful
    }
    return 0;  // Communication failed
}