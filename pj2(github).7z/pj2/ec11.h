// ec11.h - EC11 rotary encoder driver
#ifndef __EC11_H__
#define __EC11_H__

#include "config.h"

// EC11 pin definitions
sbit EC11_A = P3^2;
sbit EC11_B = P3^3;
sbit EC11_KEY = P3^4;

// Global variables
uchar ec11_last_state = 0;

// Initialize EC11
void EC11_Init(void) {
    EC11_A = 1;
    EC11_B = 1;
    EC11_KEY = 1;
}

// Read rotary encoder
// Return: 1=CW rotation, -1=CCW rotation, 0=no rotation
char EC11_Read(void) {
    uchar current_state;
    char direction = 0;
    
    // Read current state
    current_state = 0;
    if(EC11_A) current_state |= 0x02;
    if(EC11_B) current_state |= 0x01;
    
    if(ec11_last_state != current_state) {
        // Detect rotation direction based on state transition
        if(ec11_last_state == 0x03) {
            if(current_state == 0x02) direction = 1;
            if(current_state == 0x01) direction = -1;
        }
        else if(ec11_last_state == 0x02) {
            if(current_state == 0x00) direction = 1;
            if(current_state == 0x03) direction = -1;
        }
        else if(ec11_last_state == 0x00) {
            if(current_state == 0x01) direction = 1;
            if(current_state == 0x02) direction = -1;
        }
        else if(ec11_last_state == 0x01) {
            if(current_state == 0x03) direction = 1;
            if(current_state == 0x00) direction = -1;
        }
        
        ec11_last_state = current_state;
    }
    
    return direction;
}

// Check if key is pressed
uchar EC11_KeyPressed(void) {
    static uchar key_state = 1;
    static uchar key_count = 0;
    
    if(EC11_KEY == 0) {
        if(key_state == 1) {
            key_count++;
            if(key_count > 5) {  // Debounce
                key_state = 0;
                return 1;
            }
        }
    } else {
        key_state = 1;
        key_count = 0;
    }
    
    return 0;
}

#endif