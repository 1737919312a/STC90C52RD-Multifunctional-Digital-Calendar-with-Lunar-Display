// dht11.c - DHT11 温湿度传感器驱动实现文件
#include "dht11.h"
#include "config.h"  // 包含 config.h 以获取 Delay_us 的声明

// 外部函数声明：微秒延时函数 (通常在 main.c 或其他工具文件中定义)
extern void Delay_us(register uint us);

// DHT11 发送启动信号函数
void DHT11_Start(void) {
    DHT11_DQ = 1;       // 确保总线处于高电平（空闲状态）
    Delay_us(10);       // 短暂延时，等待电平稳定
    
    
    
    DHT11_DQ = 0;       // 拉低总线，发起开始信号
    //Delay_ms(20);     // (原代码注释) 拉低至少 18ms 以唤醒传感器 [注意：此行被注释，实际运行可能需要取消注释]
    DHT11_DQ = 1;       // 拉高总线，释放控制权，准备接收响应
    Delay_us(30);       // 等待 DHT11 响应 (DHT11 检测到起始信号后会等待 20-40us)
}

// 读取一个字节 (8位) 数据
uchar DHT11_ReadByte(void) {
    uchar i, dat = 0;
    
    

    for(i = 0; i < 8; i++) {
        // 等待 50us 的低电平信号结束 (这是每一位数据的起始时隙)
        while(DHT11_DQ == 0);
        
        Delay_us(30);  // 延时约 30us (26-28us) 用于采样数据位
                       // 如果是 '0'，高电平持续 26-28us，延时后总线应为低
                       // 如果是 '1'，高电平持续 70us，延时后总线仍为高
        
        dat <<= 1;     // 将当前数据左移一位，为新读取的位腾出最低位
        if(DHT11_DQ) { // 如果延时后总线仍为高电平
            dat |= 0x01;    // 说明该位是 '1'，将最低位置 1
            // 等待剩余的高电平信号结束，准备下一位
            while(DHT11_DQ == 1);
        }
        // 如果总线为低电平，说明该位是 '0'，不做操作 (最低位默认为0)
    }
    
    return dat; // 返回读取到的字节
}

// 读取温湿度数据
// 参数：buf 指向存储结果的数组
// buf[0]=湿度整数, buf[1]=温度整数
// 返回值：1=成功, 0=失败 (无响应或校验错误)
bit DHT11_Read(uchar *buf) {
    uchar i;
    uchar checksum;     // 用于存储计算的校验和
    uchar temp_buf[5];  // 临时缓冲区，存储读出的 5 个字节 (湿度整数, 湿度小数, 温度整数, 温度小数, 校验和)
    
    // 主机发送启动信号
    DHT11_Start();
    
    // 等待 DHT11 响应信号
    if(DHT11_DQ == 1) return 0;  // 如果总线一直为高，说明传感器无响应，返回失败
    
    while(DHT11_DQ == 0);  // 等待 80us 的低电平响应信号结束
    while(DHT11_DQ == 1);  // 等待 80us 的高电平准备信号结束，之后传感器开始发送数据
    
    // 循环读取 40 位数据 (5 个字节)
    for(i = 0; i < 5; i++) {
        temp_buf[i] = DHT11_ReadByte();
    }
    
    // 计算校验和
    // 校验规则：前4个字节之和的低8位应等于第5个字节
    checksum = 0;
    for(i = 0; i < 4; i++) {
        checksum += temp_buf[i];
    }
    
    // 验证校验和是否正确
    if(checksum == temp_buf[4]) {
        buf[0] = temp_buf[0];  // 提取湿度整数部分
        buf[1] = temp_buf[2];  // 提取温度整数部分 (temp_buf[1]和[3]分别是湿度和温度的小数部分，此处忽略)
        return 1;  // 读取成功
    }
    
    return 0;  // 校验错误，返回失败
}

// 微秒级延时函数封装
void DHT11_Delay_us(uint us) {
    while(us--) {
        Delay_us(1);  // 调用外部定义的 Delay_us 函数
    }
}