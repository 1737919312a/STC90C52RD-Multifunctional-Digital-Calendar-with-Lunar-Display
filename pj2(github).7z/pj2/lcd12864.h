// lcd12864.h - LCD12864 显示屏驱动头文件 (基于 ST7920 控制器)
#ifndef __LCD12864_H__    // 防止头文件重复包含的保护宏（开始）
#define __LCD12864_H__    // 定义宏 __LCD12864_H__

#include "config.h"       // 包含系统配置文件（引入 uchar, uint, reg52.h 等定义）

// --- LCD 控制引脚定义 ---
// sbit 定义特殊功能寄存器位，映射到单片机的物理引脚 P2.2 - P2.6



sbit LCD_RS = P2^2;  // 寄存器选择信号 (Register Select): 
                     // H:数据寄存器, L:指令寄存器 (在串行模式下作为 CS 片选)

sbit LCD_RW = P2^3;  // 读/写控制信号 (Read/Write): 
                     // H:读操作, L:写操作 (在串行模式下作为 SID 数据线)

sbit LCD_EN = P2^4;  // 使能信号 (Enable): 
                     // 下降沿触发数据锁存 (在串行模式下作为 SCLK 时钟线)

sbit LCD_PSB = P2^5; // 并行/串行模式选择 (Parallel/Serial Block): 
                     // H(1)=并行模式, L(0)=串行模式。本项目需置1以使用 P0 口传输数据

sbit LCD_RST = P2^6; // 复位信号 (Reset): 
                     // 低电平有效，用于硬件复位 LCD 模块

// --- LCD 数据端口定义 ---
// 定义 P0 端口为 8位并行数据总线
// 注意：在 51 单片机中，P0 口通常需要接上拉电阻才能作为普通 I/O 输出
#define LCD_DATA P0

// --- 函数原型声明 ---

// 初始化 LCD: 设置模式、清除屏幕、设置光标等
void LCD_Init(void);

// 写指令: 向 LCD 发送控制命令 (如清屏 0x01, 设置地址等)
void LCD_WriteCmd(uchar cmd);

// 写数据: 向 LCD 发送要显示的实际数据 (字符/汉字的编码)
void LCD_WriteData(uchar dat);

// 清屏: 清除显示内容并将光标归位
void LCD_Clear(void);

// 设置光标位置
// x: 行号 (0-3), y: 列号 (0-7, 每列对应两个英文字符宽)
void LCD_SetPos(uchar x, uchar y);

// 显示字符串
// x, y: 起始坐标; str: 字符串指针
void LCD_ShowString(uchar x, uchar y, uchar *str);

// 显示单个字符
// x, y: 坐标; ch: ASCII 字符
void LCD_ShowChar(uchar x, uchar y, uchar ch);  

#endif // 防止头文件重复包含的保护宏（结束）